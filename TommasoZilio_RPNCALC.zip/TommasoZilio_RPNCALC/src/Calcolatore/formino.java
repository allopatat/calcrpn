package Calcolatore;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Stack;

public class formino {

    private JPanel panelo;
    private JButton zero;
    private JButton uno;
    private JButton due;
    private JButton tre;
    private JButton quatro;
    private JButton cinque;
    private JButton sei;
    private JButton sete;
    private JButton oto;
    private JButton nove;
    private JButton più;
    private JButton meno;
    private JButton molt;
    private JButton div;
    private JButton equal;
    private JButton canc;
    private JTextField TextField1;
    private JButton par1;
    private JButton par2;
    private JButton errepienne;

    public formino() {
        zero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "0");
            }
        });
        uno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "1");
            }
        });
        due.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "2");
            }
        });
        tre.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "3");
            }
        });
        quatro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "4");
            }
        });
        cinque.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "5");
            }
        });
        sei.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "6");
            }
        });
        sete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "7");
            }
        });
        oto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "8");
            }
        });
        nove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "9");
            }
        });
        più.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "+");
            }
        });
        meno.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "-");
            }
        });
        molt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "*");
            }
        });
        div.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "/");
            }
        });
        par1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + "(");
            }
        });
        par2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText(TextField1.getText() + ")");
            }
        });
        canc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TextField1.setText("");
            }
        });
        equal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String espressioneInfix = TextField1.getText();
                String espressioneRPN = Calcolatore.convertiInRPN(espressioneInfix);
                String risultato = Calcolatore.calcolaRPN(espressioneRPN);
                TextField1.setText(risultato);
            }

        });

        errepienne.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String espressioneRPN = TextField1.getText();
                String risultato = Calcolatore.calcolaRPN(espressioneRPN);
                TextField1.setText(risultato);
            }
        });
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("Calcolatore");
        frame.setContentPane(new formino().panelo);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }


    public static class Calcolatore {

        public static String calcolaRPN(String espressioneRPN) {
            Stack<String> stack = new Stack<>();

            for (String token : espressioneRPN.split(" ")) {
                if (isOperatore(token)) {
                    String operand2 = stack.pop();
                    String operand1 = stack.pop();
                    double op1 = Double.parseDouble(operand1);
                    double op2 = Double.parseDouble(operand2);
                    double risultato = 0;

                    switch (token) {
                        case "+":
                            risultato = op1 + op2;
                            break;
                        case "-":
                            risultato = op1 - op2;
                            break;
                        case "*":
                            risultato = op1 * op2;
                            break;
                        case "/":
                            if (op2 == 0) {
                                return "Errore: divisione per zero";
                            }
                            risultato = op1 / op2;
                            break;
                        default:
                            return "Errore: operatore sconosciuto: " + token;
                    }

                    stack.push(String.valueOf(risultato));
                } else {
                    stack.push(token);
                }
            }

            if (stack.size() == 1) {
                return stack.pop();
            } else {
                return "Errore: espressione non valida";
            }
        }

        public static String convertiInRPN(String espressioneInfix) {
            StringBuilder espressioneRPN = new StringBuilder();
            Stack<Character> operatorStack = new Stack<>();

            for (int i = 0; i < espressioneInfix.length(); i++) {
                char carattere = espressioneInfix.charAt(i);

                if (Character.isDigit(carattere) || carattere == '.') {
                    // Se il carattere è un numero o un punto decimale, aggiungi direttamente all'output.
                    while (i < espressioneInfix.length() && (Character.isDigit(espressioneInfix.charAt(i)) || espressioneInfix.charAt(i) == '.')) {
                        espressioneRPN.append(espressioneInfix.charAt(i));
                        i++;
                    }
                    espressioneRPN.append(" ");
                    i--;
                } else if (carattere == '(') {
                    // Se il carattere è una parentesi aperta, inserisci nello stack degli operatori.
                    operatorStack.push(carattere);
                } else if (carattere == ')') {
                    // Se il carattere è una parentesi chiusa, sposta gli operatori nello stack all'output fino a quando
                    // incontra una parentesi aperta.
                    while (!operatorStack.isEmpty() && operatorStack.peek() != '(') {
                        espressioneRPN.append(operatorStack.pop()).append(" ");
                    }
                    operatorStack.pop(); // Rimuovi la parentesi aperta.
                } else if (isOperatore(String.valueOf(carattere))) {
                    // Se il carattere è un operatore, sposta gli operatori nello stack all'output in base alla precedenza.
                    while (!operatorStack.isEmpty() && precedenza(operatorStack.peek()) >= precedenza(carattere)) {
                        espressioneRPN.append(operatorStack.pop()).append(" ");
                    }
                    operatorStack.push(carattere);
                }
            }

            // Sposta gli operatori rimanenti nello stack all'output.
            while (!operatorStack.isEmpty()) {
                espressioneRPN.append(operatorStack.pop()).append(" ");
            }

            return espressioneRPN.toString().trim();
        }


        private static boolean isOperatore(String token) {
            return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/");
        }



        private static int precedenza(char operatore) {
            switch (operatore) {
                case '+':
                case '-':
                    return 1;
                case '*':
                case '/':
                    return 2;
                default:
                    return 0; // Operatori non validi o parentesi.
            }
        }
    }

    }